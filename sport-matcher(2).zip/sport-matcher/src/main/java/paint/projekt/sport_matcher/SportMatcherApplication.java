package paint.projekt.sport_matcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportMatcherApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportMatcherApplication.class, args);
	}

}
